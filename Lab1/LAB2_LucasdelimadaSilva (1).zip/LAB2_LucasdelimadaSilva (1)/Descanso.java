package LAB2_LucasdelimadaSilva;

public class Descanso {
    private int horasDescanso;
    private int numerosSemana;
    
    public Descanso() {
        this.horasDescanso = 0;
        this.numerosSemana = 1;
    }

    void defineHorasDescanso(int horasDescanso) {
        this.horasDescanso = horasDescanso;
    }

    public void defineNumeroSemanas(int numerosSemana) {
        this.numerosSemana = numerosSemana;
    }
    
    public String getStatusGeral() {
        if((horasDescanso / numerosSemana) >= 26) {
            return "descansado";
        } else {
            return "cansado";
        }
    }
}