package com.matheusgr.apresentacao;

import com.matheusgr.lunr.documento.DocumentoService;

/**
 * Componente para tratamento da lógica de negócio relativa 
 * a apresentação de documentos.
 */
public class ApresentacaoService {

	private DocumentoService documentoService;

	/**
	 * Inicialização da lógica de serviço.
	 * 
	 * @param documentoService DocumentoService a ser utilizado pelo
	 *                         ApresentacaoService.
	 */
	public ApresentacaoService(DocumentoService documentoService) {
		this.documentoService = documentoService;
	}

	/**
	 * Realiza a apresentação do documento indicado.
	 *  
	 * @param docId1 Documento a ser apresentado.
	 * @param tipoApresentacao modo de apresentacao a ser aplicado sobre o documento.
	 */
	public String apresenta(String docId, String tipoApresentacao) {
		if (this.documentoService.recuperaDocumento(docId).isEmpty()) {
			return "";
		}
		String apresentacao = this.documentoService.recuperaDocumento(docId).toString();
		String[] padraoDeRepresentacao = tipoApresentacao.split(" ");
		String metodoDeRepresentacao = "";
		int qtdLinhas = 0;
		for (int i = 0; i < padraoDeRepresentacao.length; i++) {
			if(padraoDeRepresentacao[i].toUpperCase().equals("PRIMEIRAS")) {
				metodoDeRepresentacao = "PRIMEIRAS";
			}
			if((Integer.parseInt(padraoDeRepresentacao[i])) == int) {
				
			}
		}
		return apresentacao;
		
	}

}
