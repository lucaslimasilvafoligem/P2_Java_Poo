package LAB2_LucasdelimadaSilva;

public class AtividadesComplementares {
    private String[] atividadesRealizadas;
    private String listaEstagio;
    private String listaProjeto;
    private double horasCurso;
    private int creditosEstagio;
    private int creditosProjeto;
    private int creditosCurso;
    private int creditosTotais;
    private int estagios;
    private int projetos;

    public AtividadesComplementares() {
        this.estagios = 0;
        this.projetos = 0;
        this.listaEstagio = "";
        this.listaProjeto = "";
    }
    
    public void adicionarEstagio(int horas) {
        if(this.estagios <= 9) {
            this.estagios += 1;
            this.creditosEstagio += 5 * (horas / 300);
            this.listaEstagio += "Estagio " + horas + "!";
        }
    }

    public void adicionarProjeto(int meses) {
        if(projetos <= 16) { 
            this.projetos += 1;
            this.creditosProjeto += 2 * (meses / 3); 
            this.listaProjeto += "Projeto " + meses + "!";
        }
    }

    public void adicionarCurso(double horas) {
        this.creditosCurso = 0;
        this.horasCurso += horas;
        this.creditosCurso += this.horasCurso / 30;
    }
    
    public String[] pegaAtividades() {
        this.atividadesRealizadas = new String[this.estagios + this.projetos + 4];
        String[] arrayEstagio = listaEstagio.split("!");
        String[] arrayProjeto = listaProjeto.split("!");
        for(int x = 0; x < this.atividadesRealizadas.length - this.projetos - 4; x++) { 
            this.atividadesRealizadas[x] = arrayEstagio[x];
        }
        for(int i = 0; i < this.atividadesRealizadas.length - this.estagios - 4; i++) {
            this.atividadesRealizadas[estagios + i] = arrayProjeto[i];
        }

        for(int w = 0; w < 5; w++) {
            if(w == 0) {
                atividadesRealizadas[estagios + projetos + w] = "Cursos " + this.horasCurso;
            }
            if(w == 1) {
                atividadesRealizadas[estagios + projetos + w] = "Creditos_Estagio " + this.creditosEstagio;
            }
            if(w == 2) {
                atividadesRealizadas[estagios + projetos + w] = "Creditos_Projeto " + this.creditosProjeto;
            }
            if(w == 3) {
                atividadesRealizadas[estagios + projetos + w] = "Creditos_Cursos " + this.creditosCurso;
            }

        }
        return atividadesRealizadas;
    }

    public int contaCreditos() {
        this.creditosTotais = creditosCurso + creditosEstagio + creditosProjeto;
        return creditosTotais;
    }
}