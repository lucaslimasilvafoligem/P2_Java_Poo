package LAB2_LucasdelimadaSilva;

public class RegistroTempoOnline {
    private String nomedisciplina;
    private int tempogastoOnline;
    private int tempoEsperado;
    
    public RegistroTempoOnline (String nomeDisciplina) { 
        this.nomedisciplina = nomeDisciplina;
        this.tempoEsperado = 120;
        this.tempogastoOnline = 0;
    }
    
    public RegistroTempoOnline (String nomeDisciplina, int tempoOnlineEsperado) {
        this.nomedisciplina = nomeDisciplina;
        this.tempoEsperado = tempoOnlineEsperado;
        this.tempogastoOnline = 0;   
    }

    public void adicionaTempoOnline(int tempo) {
        this.tempogastoOnline += tempo;
    }

    public boolean atingiuMetaTempoOnline() {
        return this.tempogastoOnline >= this.tempoEsperado;
    }
    
    public String toString() {
        return this.nomedisciplina + " " + this.tempogastoOnline + "/" + this.tempoEsperado;
    }
}