package LAB2_LucasdelimadaSilva;

public class Disciplina {
    private String nomeDisciplina;
    private int horasEstudo;
    private int[] notas = new int[4];
    private double[] notasAluno = new double[4];
    private double media;
    private String listaNotas;

    public Disciplina(String nomeDisciplina) {
        this.media = 0;
        this.nomeDisciplina = nomeDisciplina;
        this.horasEstudo = 0;
        for(int k = 0; k < notas.length; k++) {
            this.notas[k] = k + 1;
        }
    }

    public void cadastraHoras(int horas) {
        this.horasEstudo += horas;
    }

    public void cadastraNota(int nota, double valornotas) {
        for(int i = 0; i < notas.length; i++) {
            if(this.notas[i] == nota) {
                this.notasAluno[i] = valornotas;
            } 
        }
    }

    private double calculaMedia() {
        double somaNotas = 0;
        this.media = 0;
        for(int j = 0; j < notas.length; j++) {
            somaNotas += this.notasAluno[j];
        }
        this.media = somaNotas / this.notas.length;
        return this.media;   
    }

    public boolean aprovado() {
        return calculaMedia() >= 7;
    }

    public String toString() {
        this.listaNotas = "[";
        calculaMedia();
        for(int x = 0; x < this.notas.length; x++) {
            this.listaNotas += notasAluno[x];
            if(x + 1 < this.notas.length) {
                this.listaNotas += ",";
                this.listaNotas += " ";
            } else {
                this.listaNotas += "]";
            }
        }
        return this.nomeDisciplina + " " + this.horasEstudo + " " + this.media + " " + this.listaNotas;
    }
}
